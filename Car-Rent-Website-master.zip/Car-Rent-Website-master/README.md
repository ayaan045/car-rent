# Car-Rent-Website

Car_Rent_Website project, the name itself suggests that it's for car rent purposes. Buyer can easily rent their budgeted car at a suitable cost. This project is created using HTML 5, CSS 3, Bootstrap, Javascript with Swiper.js library, and PHP with MySQL database connectivity is at the backend.
